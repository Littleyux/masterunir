$(document).ready(function() {
	var ver_grid_lines_x=false;
	var ver_grid_lines_y2=false;
	var ver_grid_lines_y1=false;
	var yaxis2="y";
	var qlayout=1;

	$('#Tipo').prop('disabled', true);
	$('#Tipo').selectpicker('refresh');

	//Obtenemos las empresas dsponibles	
    $.ajax({
		dataType: "json",
        url: "http://localhost:3000/api/testings/company/1"
    }).then(function(data) {
		$('.myid').append(data[0]._id);
		$('.mycontent').append(data[0].testfile);
		$('.mytype').append(data[0].type);
		var datos = data[0].data;
		//alert("cantidad de datos:" + datos.length);
		$.each(datos, function(key,val){
			$.each(val, function(key2,val2){
				//alert(key2);
				if (Array.isArray(val2)){
					//alert(val2[0]);
				}
				else{
					//alert(val2);
				}
			});
		});
    });

	//Rellenar dinamicamente el selector de empresas
	$.ajax({
		dataType: "json",
        url: "http://localhost:3000/api/testings/getCompanies/numero"
    }).then(function(data) {
		const obj = JSON.parse(JSON.stringify(data));
		//alert(obj.companies.length)
		$.each(obj.companies,function(i,e){
			$("#empresa").append('<option value="'+e+'">'+e+'</option>');
		});
		$("#empresa").selectpicker('refresh');
	});	


	//Rellenar dinamicamente el selector de Tipos despues de seleccionar la empresa
	$("#empresa").change(function(){
		$.ajax({
			dataType: "json",
			url: "http://localhost:3000/api/testings/getTipos/" + $("#empresa").val()
		}).then(function(data) {
			const obj = JSON.parse(JSON.stringify(data));
			//alert(obj.tipos.length)
			$("#Tipo").find('option').remove();//eliminamos las opciones existentes
			$("#Tipo").selectpicker("refresh");
			$.each(obj.tipos,function(i,e){//rellenamos con las nuevas opciones
				$("#Tipo").append('<option value="'+e+'">'+e+'</option>');
			});
			$('#Tipo').prop('disabled', false);//activamos el selector de tipos
			$("#Tipo").selectpicker('refresh');//refrescamos el selector para aplicar cambios
		});
	});

	$("#Tipo").change(function(){
		$.ajax({
			dataType: "json",
			url: "http://localhost:3000/api/testings/getTestings/" + $("#empresa").val() + "/" + $("#Tipo").val()
		}).then(function(data) {
			//alert("cantidad de objetos:" + data.length);
			$("#results").html("results: "+ data.length);
			$("#results").css('visibility', 'visible');
			$("#ensayos").find('option').remove();//eliminamos las opciones existentes
			$("#ensayos").selectpicker("refresh");
			$.each(data, function(key,val){
				//alert(val._id);
				$("#ensayos").append('<option value="'+val._id+'">'+val.testfile+'</option>');
			});
			$("#ensayos").selectpicker('refresh');
		});
	});

	$("#ensayos").change(function(){
		id=$("#ensayos").val();
		$.ajax({
			dataType: "json",
			url: "http://localhost:3000/api/testings/getAxis/" + id
		}).then(function(data) {
			//alert("cantidad de objetos:" + data.length);
			$("#ejex").find('option').remove();//eliminamos las opciones existentes
			$("#ejey").find('option').remove();//eliminamos las opciones existentes
			$("#ejey2").find('option').remove();//eliminamos las opciones existentes
			const obj = JSON.parse(JSON.stringify(data));
			$.each(obj.ejes, function(key,val){
				//alert(val);
				$("#ejex").append('<option value="'+val+'">'+val+'</option>');
				$("#ejey").append('<option value="'+val+'">'+val+'</option>');
				$("#ejey2").append('<option value="'+val+'">'+val+'</option>');
				//$("#ensayos").append('<option value="'+val._id+'">'+val.testfile+'</option>');
			});
			$("#ejex").selectpicker('refresh');
			$("#ejey").selectpicker('refresh');
			$("#ejey2").selectpicker('refresh');
		});
	});

	$("#btn-view-data").click(function(){
		cerrar_menu();
		
		
		//id="61f0150fed2221fc4fe8fe9a";
		//id="621684407bf9731d0676dbfe"; //4705 registros
		//id="62168a2db30325270204d7ad";//33000 registros
		id=$("#ensayos").val();
		graficar(id);
	});

	$(".closebtn").click(function(){
		cerrar_menu();
	});

	$("#btn-options").click(function(){
		$("#accordion").attr("style", "visibility: visible");
		console.log("adios");
	});

	function cerrar_menu(){
		$("#accordion").hide();
		closeNav();
	}
	
	$("#chk_enable_y2").change(function() {
		if(this.checked) {
			//alert("enabled");
			$("#ejey2").prop("disabled", false);
			$("#ejey2").selectpicker('refresh');
			$("#chk_grid_y2").prop("disabled", false);
			yaxis2="y2";
			qlayout=2;
		}
		else{
			//alert("disabled");
			$("#ejey2").prop("disabled", true);
			$("#ejey2").selectpicker('refresh');
			$("#chk_grid_y2").prop("disabled", true);
			yaxis2="y";
			qlayout=1;
		}
	});

	$("#chk_grid_y1").change(function() {
		if(this.checked){
			ver_grid_lines_y1=true;
		}
		else{
			ver_grid_lines_y1=false;
		}
	});

	$("#chk_grid_y2").change(function() {
		if(this.checked){
			ver_grid_lines_y2=true;
		}
		else{
			ver_grid_lines_y2=false;
		}
	});

	$("#chk_grid_x").change(function() {
		if(this.checked){
			ver_grid_lines_x=true;
		}
		else{
			ver_grid_lines_x=false;
		}
	});
	
	function graficar(id){
		const names=[];//cada elemento será un string
		const values=[];//cada elemento será un array de valores
		alert(id);
		myurl="http://localhost:3000/api/testings/" + id
		$.ajax({
			dataType: "json",
			url: myurl
		}).then(function(data) {
			//$('.myid').append(data._id);
			//$('.mycontent').append(data.testfile);
			//$('.mytype').append(data.type);
			var datos = data.data;
			
			var i=0;
			//alert("cantidad de objetos encontrados:" + datos.length);
			$.each(datos, function(key,val){
				$.each(val, function(key2,val2){
					if (Array.isArray(val2)){
						//Guardamos el array de valores
						values[i]=val2;
					}
					else{
						//Guardamos el nombre
						names[i]=val2;
					}
				});
				i=i+1;//pasamos al siguiente objeto del array
			});
			//comprobamos lo que hemos obtenido
			//alert(names.toString());
			//alert(values[2].length);
			
			

			var trace1 = {
			x: values[names.indexOf($("#ejex").val())], //Buscamos la posicion en names del valor seleccionado para el eje x
			y: values[names.indexOf($("#ejey").val())],
			//text: ['B-a', 'B-b', 'B-c', 'B-d', 'B-e'],
			mode: 'lines', //markers, lines+markers,...
			type: 'scatter',
			name: 'trace 1'
			};


			var trace2 = {
			x: values[names.indexOf($("#ejex").val())], //Buscamos la posicion en names del valor seleccionado para el eje x
			y: values[names.indexOf($("#ejey2").val())],
			name: 'yaxis2 data',
			yaxis: yaxis2, // opcion para cuando hay 2 ejes Y  -->      
			type: 'scatter'
			};

			var layout1 = {
				autosize: false,
  				width: 1000,
  				height: 700,
				xaxis: {
					showgrid:ver_grid_lines_x,
					title: $("#ejex").val()
				},
				yaxis: {
					showgrid:ver_grid_lines_y1,
					title: $("#ejey").val(),
					//type: 'log'
				},
				
				title: 'Scroll and Zoom',
				showlegend: true,
				font: {size: 12},
				
			};

			var layout2 = {
				autosize: false,
  				width: 1000,
  				height: 700,
				xaxis: {
					showgrid:ver_grid_lines_x,
					title: $("#ejex").val()
				},
				yaxis: {
					showgrid:ver_grid_lines_y1,
					title: $("#ejey").val(),
					//type: 'log'
				},
				yaxis2: {
					title: $("#ejey2").val(),
					showgrid:ver_grid_lines_y2, 
					titlefont: {color: 'rgb(148, 103, 189)'},
					tickfont: {color: 'rgb(148, 103, 189)'},
					overlaying: 'y',
					side: 'right'
				  },
				title: 'Scroll and Zoom',
				showlegend: true,
				font: {size: 12},
				
			};

			var config = {
				modeBarButtonsToAdd:['toggleSpikelines'],
				modeBarButtonsToRemove:['resetScale2d'],
				scrollZoom: true,
				editable: true,
				displaylogo: false,
				responsive: true
			};

			var data
			if(qlayout==1){
				layout=layout1;
				data = [trace1];
			}
			else
			{
				layout=layout2;
				data = [trace1, trace2];
			}

			Plotly.newPlot('myDiv', data, layout, config);		
		});
	}

});