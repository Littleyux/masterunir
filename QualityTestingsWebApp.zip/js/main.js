// mousewheel or two-finger scroll zooms the plot

var trace1 = {
  x: [1, 2, 3, 4],
  y: [10, 15, 13, 17],
  //text: ['B-a', 'B-b', 'B-c', 'B-d', 'B-e'],
  mode: 'markers',
  type: 'scatter',
  name: 'trace 1'
};

var trace2 = {
  x: [2, 3, 4, 5],
  y: [16, 5, 11, 9],
  mode: 'lines',
  type: 'scatter',
  name: 'trace 2'
};

var trace3 = {
  x: [1, 2, 3, 4],
  y: [12, 9, 15, 12],
  mode: 'lines+markers',
  type: 'scatter',
  name: 'trace 3'
};

var data = [trace1, trace2, trace3];

var layout = {
	xaxis: {
      title: 'Life Expectancy'
    },
    yaxis: {
      title: 'GDP per Capita',
      type: 'log'
    },
    title: 'Scroll and Zoom',
    showlegend: true,
	font: {size: 12},
	
};

var config = {
	modeBarButtonsToAdd:['toggleSpikelines'],
	modeBarButtonsToRemove:['resetScale2d'],
	scrollZoom: true,
	editable: true,
	displaylogo: false,
	responsive: true
};

Plotly.newPlot('myDiv', data, layout, config);