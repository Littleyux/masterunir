$(document).ready(function() {
	var ver_grid_lines_x=false;
	var ver_grid_lines_y2=false;
	var ver_grid_lines_y1=false;
	var yaxis2="y";
	var qlayout=1;
	var ejes_ensayo=[];
	var ensayos=[];
	var valores=[];
	var nombres=[];
	var v_pearson=[];
	var v_spearman=[];

	$('#Tipo').prop('disabled', true);
	$('#Tipo').selectpicker('refresh');

	//Obtenemos las empresas dsponibles	
    $.ajax({
		dataType: "json",
        url: "http://localhost:3000/api/testings/company/1"
    }).then(function(data) {
		$('.myid').append(data[0]._id);
		$('.mycontent').append(data[0].testfile);
		$('.mytype').append(data[0].type);
		var datos = data[0].data;
		//alert("cantidad de datos:" + datos.length);
		$.each(datos, function(key,val){
			$.each(val, function(key2,val2){
				//alert(key2);
				if (Array.isArray(val2)){
					//alert(val2[0]);
				}
				else{
					//alert(val2);
				}
			});
		});
    });

	//Rellenar dinamicamente el selector de empresas
	$.ajax({
		dataType: "json",
        url: "http://localhost:3000/api/testings/getCompanies/numero"
    }).then(function(data) {
		const obj = JSON.parse(JSON.stringify(data));
		//alert(obj.companies.length)
		$.each(obj.companies,function(i,e){
			$("#empresa").append('<option value="'+e+'">'+e+'</option>');
		});
		$("#empresa").selectpicker('refresh');
	});	


	//Rellenar dinamicamente el selector de Tipos despues de seleccionar la empresa
	$("#empresa").change(function(){
		$.ajax({
			dataType: "json",
			url: "http://localhost:3000/api/testings/getTipos/" + $("#empresa").val()
		}).then(function(data) {
			const obj = JSON.parse(JSON.stringify(data));
			//alert(obj.tipos.length)
			$("#Tipo").find('option').remove();//eliminamos las opciones existentes
			$("#Tipo").selectpicker("refresh");
			$.each(obj.tipos,function(i,e){//rellenamos con las nuevas opciones
				$("#Tipo").append('<option value="'+e+'">'+e+'</option>');
			});
			$('#Tipo').prop('disabled', false);//activamos el selector de tipos
			$("#Tipo").selectpicker('refresh');//refrescamos el selector para aplicar cambios
		});
	});

	$("#Tipo").change(function(){
		$.ajax({
			dataType: "json",
			url: "http://localhost:3000/api/testings/getTestings/" + $("#empresa").val() + "/" + $("#Tipo").val()
		}).then(function(data) {
			//alert("cantidad de objetos:" + data.length);
			$("#results").html("results: "+ data.length);
			$("#results").css('visibility', 'visible');
			$("#ensayos").find('option').remove();//eliminamos las opciones existentes
			$("#ensayos").selectpicker("refresh");
			$.each(data, function(key,val){
				//alert(val._id);
				$("#ensayos").append('<option value="'+val._id+'">'+val.testfile+'</option>');
			});
			$("#ensayos").selectpicker('refresh');
		});
	});

	$("#ensayos").change(function(){
		v_id=$("#ensayos").val();
		if(v_id==null)
		{
			ensayos=[];
			ejes_ensayo=[];
			//alert("vacio");
		}
		else
		{
			v_id=$("#ensayos").val().toString().split(",");
			if (v_id.length == 1)
			{
				ensayos.push(v_id[0]);
				$("#btn-splom").show();
			}
			else
			{
				$("#btn-splom").hide();
				for(i=0; i<v_id.length; i++)
				{
					//alert("comprobar " + v_id[i] + " en " + ensayos )
					if(ensayos.indexOf(v_id[i])<0)
					{
						ensayos.push(v_id[i])
					}
				}
			}

			//alert(ensayos);
			$.ajax({
				dataType: "json",
				url: "http://localhost:3000/api/testings/getAxis/" + ensayos[ensayos.length-1]
			}).then(function(data) {
				//alert("cantidad de objetos:" + data.length);
				const obj = JSON.parse(JSON.stringify(data));
				const ejes=[]
				$.each(obj.ejes, function(key,val){
					
					//alert(val + "-> " + ejes_ensayo.indexOf(val));
					if(v_id.length == 1 || ejes_ensayo.indexOf(val) >= 0)
						ejes.push(val);
					//$("#ensayos").append('<option value="'+val._id+'">'+val.testfile+'</option>');
				});
				//alert("ejes:" + ejes);
				ejes_ensayo = ejes
				//alert(ejes_ensayo.length);
				//alert(ejes);

				$("#ejex").find('option').remove();//eliminamos las opciones existentes
				$("#ejey").find('option').remove();//eliminamos las opciones existentes
				$("#ejey2").find('option').remove();//eliminamos las opciones existentes
				
				$.each(ejes_ensayo, function(key,val){
					//alert(val);
					$("#ejex").append('<option value="'+val+'">'+val+'</option>');
					$("#ejey").append('<option value="'+val+'">'+val+'</option>');
					$("#ejey2").append('<option value="'+val+'">'+val+'</option>');
					//$("#ensayos").append('<option value="'+val._id+'">'+val.testfile+'</option>');
				});
				$("#ejex").selectpicker('refresh');
				$("#ejey").selectpicker('refresh');
				$("#ejey2").selectpicker('refresh');

			});

			//$.ajax({
			//	dataType: "json",
			//	url: "http://localhost:3000/api/testings/getAxis/" + v_id[0]
			//}).then(function(data) {
			//	//alert("cantidad de objetos:" + data.length);
			//	$("#ejex").find('option').remove();//eliminamos las opciones existentes
			//	$("#ejey").find('option').remove();//eliminamos las opciones existentes
			//	$("#ejey2").find('option').remove();//eliminamos las opciones existentes
			//	const obj = JSON.parse(JSON.stringify(data));
			//	$.each(obj.ejes, function(key,val){
			//		//alert(val);
			//		$("#ejex").append('<option value="'+val+'">'+val+'</option>');
			//		$("#ejey").append('<option value="'+val+'">'+val+'</option>');
			//		$("#ejey2").append('<option value="'+val+'">'+val+'</option>');
			//		//$("#ensayos").append('<option value="'+val._id+'">'+val.testfile+'</option>');
			//	});
			//	$("#ejex").selectpicker('refresh');
			//	$("#ejey").selectpicker('refresh');
			//	$("#ejey2").selectpicker('refresh');
			//});
		}

		

		
		

		
	});
	
	$("#btn-splom").click(function(){
		id=$("#ensayos").val();
		splom(id);
	});

	$("#btn-view-data").click(function(){
		cerrar_menu();
		valores=[];
		nombres=[];
		v_pearson=[];
		v_spearman=[];
		//id="61f0150fed2221fc4fe8fe9a";
		//id="621684407bf9731d0676dbfe"; //4705 registros
		//id="62168a2db30325270204d7ad";//33000 registros
		v_id=$("#ensayos").val().toString().split(",");
		$.each(v_id, function(key,val){
			data = graficar(val);
			//alert(data.length);
		})
		
	});

	$(".closebtn").click(function(){
		cerrar_menu();
	});

	$("#btn-options").click(function(){
		$("#accordion").attr("style", "visibility: visible");
		console.log("adios");
	});

	function cerrar_menu(){
		$("#accordion").hide();
		closeNav();
	}
	
	$("#chk_enable_y2").change(function() {
		if(this.checked) {
			//alert("enabled");
			$("#ejey2").prop("disabled", false);
			$("#ejey2").selectpicker('refresh');
			$("#chk_grid_y2").prop("disabled", false);
			yaxis2="y2";
			qlayout=2;
		}
		else{
			//alert("disabled");
			$("#ejey2").prop("disabled", true);
			$("#ejey2").selectpicker('refresh');
			$("#chk_grid_y2").prop("disabled", true);
			yaxis2="y";
			qlayout=1;
		}
	});

	$("#chk_grid_y1").change(function() {
		if(this.checked){
			ver_grid_lines_y1=true;
		}
		else{
			ver_grid_lines_y1=false;
		}
	});

	$("#chk_grid_y2").change(function() {
		if(this.checked){
			ver_grid_lines_y2=true;
		}
		else{
			ver_grid_lines_y2=false;
		}
	});

	$("#chk_grid_x").change(function() {
		if(this.checked){
			ver_grid_lines_x=true;
		}
		else{
			ver_grid_lines_x=false;
		}
	});
	
	function graficar(id){
		const names=[];//cada elemento será un string
		const values=[];//cada elemento será un array de valores
		//alert(id);
		
		myurl="http://localhost:3000/api/testings/" + id
		$.ajax({
			dataType: "json",
			url: myurl
		}).then(function(data) {
			//$('.myid').append(data._id);
			//$('.mycontent').append(data.testfile);
			//$('.mytype').append(data.type);
			var datos = data.data;
			
			var i=0;
			//alert("cantidad de objetos encontrados:" + datos.length);
			$.each(datos, function(key,val){
				$.each(val, function(key2,val2){
					if (Array.isArray(val2)){
						//Guardamos el array de valores
						values[i]=val2;
					}
					else{
						//Guardamos el nombre
						names[i]=val2;
					}
				});
				i=i+1;//pasamos al siguiente objeto del array
			});
			//comprobamos lo que hemos obtenido
			//alert(names.toString());
			//alert(values[2].length);
			
			//pintar(values, names);
			valores.push(values);
			nombres.push(names);
			
			calcular_pearson(values,names);
			calcular_spearman(values,names);
			if(valores.length == ensayos.length)
			{
				//alert(values[0].length);
				pintar(valores,nombres);
				pintar_pearson_spearman();
				
			}
			else
			{
				//alert(valores.length + ", " + ensayos.length);
			}
				
		});
		
	}
	
	function calcular_pearson(values,names){
		
			v1 = values[names.indexOf($("#ejex").val())];
			v2 = values[names.indexOf($("#ejey").val())];
			v_pearson.push(pearson(v1,v2));
			//alert("pearson " + pearson(v1,v2));
			//alert(v_pearson.length);
	}
	
	function calcular_spearman(values,names){
		
			v1 = values[names.indexOf($("#ejex").val())];
			v2 = values[names.indexOf($("#ejey").val())];
			v_spearman.push(spearman(v1,v2));
			//alert(v_spearman.length);
	}

	function pintar(valores, nombres)
	{
		var data=[];
		var layout;
		var selectedText = $("#ensayos").find('option:selected').map(function() {
			return $(this).text();
			}).get().join(',');
			
		nombre_trazas=selectedText.split(",");
		for(i=0; i<valores.length; i++)
		{
			//alert(values.length);
			var trace1 = {
			x: valores[i][nombres[i].indexOf($("#ejex").val())], //Buscamos la posicion en names del valor seleccionado para el eje x
			y: valores[i][nombres[i].indexOf($("#ejey").val())],
			//text: ['B-a', 'B-b', 'B-c', 'B-d', 'B-e'],
			mode: 'lines', //markers, lines+markers,...
			type: 'scatter',
			name: nombre_trazas[i] + " [" + $("#ejey").val() + "]"
			};

			

			var trace2 = {
			x: valores[i][nombres[i].indexOf($("#ejex").val())], //Buscamos la posicion en names del valor seleccionado para el eje x
			y: valores[i][nombres[i].indexOf($("#ejey2").val())],
			name: nombre_trazas[i] + " [" + $("#ejey2").val() + "]",
			yaxis: yaxis2, // opcion para cuando hay 2 ejes Y  -->      
			type: 'scatter'
			};

			
			if(qlayout==1){
				data.push(trace1);
			}
			else
			{
				data.push(trace1);
				data.push(trace2);
			}
		}

		//alert(data.length);

		var layout1 = {
			autosize: false,
			width: 1100,
			height: 700,
			images: [
				{
				  x: 0.75,
				  y: 0.8,
				  sizex: 0.5,
				  sizey: 0.5,
				  source: "logo2.png",
				  xanchor: "right",
				  xref: "paper",
				  yanchor: "top",
				  yref: "paper"
				}
			],
			xaxis: {
				showgrid:ver_grid_lines_x,
				title: $("#ejex").val()
			},
			yaxis: {
				showgrid:ver_grid_lines_y1,
				title: $("#ejey").val(),
				//type: 'log'
			},
			
			title: 'Scroll and Zoom',
			showlegend: true,
			font: {size: 12},
			
		};

		var layout2 = {
			autosize: false,
			width: 1100,
			height: 700,
			images: [
				{
				  x: 0.75,
				  y: 0.8,
				  sizex: 0.5,
				  sizey: 0.5,
				  source: "logo2.png",
				  xanchor: "right",
				  xref: "paper",
				  yanchor: "top",
				  yref: "paper"
				}
			],
			xaxis: {
				showgrid:ver_grid_lines_x,
				title: $("#ejex").val()
			},
			yaxis: {
				showgrid:ver_grid_lines_y1,
				title: $("#ejey").val(),
				//type: 'log'
			},
			yaxis2: {
				title: $("#ejey2").val(),
				showgrid:ver_grid_lines_y2, 
				titlefont: {color: 'rgb(148, 103, 189)'},
				tickfont: {color: 'rgb(148, 103, 189)'},
				overlaying: 'y',
				side: 'right'
			},
			title: 'Scroll and Zoom',
			showlegend: true,
			font: {size: 12},
			
		};

		if(qlayout==1){
			layout=layout1;
		}
		else
		{
			layout=layout2;
		}

		var config = {
			modeBarButtonsToAdd:['toggleSpikelines'],
			modeBarButtonsToRemove:['resetScale2d'],
			scrollZoom: true,
			editable: true,
			displaylogo: false,
			responsive: true
		};
			
			Plotly.newPlot('myDiv', data, layout, config);
	}
	
	function pintar_pearson_spearman(){
		
		var selectedText = $("#ensayos").find('option:selected').map(function() {
			return $(this).text();
			}).get().join(',');
			
		nombre_trazas=selectedText.split(",");
		
		mi_html="<h4><b>Coeficientes de correlacion</b> ("+$("#ejex").val()+" / "+$("#ejey").val()+")</h4>"
		mi_html+="<table width=800><tr><th>Fichero</th><th>Pearson</th><th>Spearman</th></tr>"
		for(i=0; i<v_pearson.length; i++)
			mi_html += "<tr><td>"+nombre_trazas[i]+"</td><td>" +v_pearson[i]+"</td><td>"+v_spearman[i]+"</td></tr>"
		mi_html+="</table>"
		$("#correlation").html(mi_html);
	}
	
	
	function splom(id){
		const names=[];//cada elemento será un string
		const values=[];//cada elemento será un array de valores
		//alert(id);
		
		myurl="http://localhost:3000/api/testings/" + id
		$.ajax({
			dataType: "json",
			url: myurl
		}).then(function(data) {
			//$('.myid').append(data._id);
			//$('.mycontent').append(data.testfile);
			//$('.mytype').append(data.type);
			var datos = data.data;
			
			var i=0;
			//alert("cantidad de objetos encontrados:" + datos.length);
			$.each(datos, function(key,val){
				$.each(val, function(key2,val2){
					if (Array.isArray(val2)){
						//Guardamos el array de valores
						values[i]=val2;
						
					}
					else{
						//Guardamos el nombre
						names[i]=val2;
					}
				});
				i=i+1;//pasamos al siguiente objeto del array
			});
			//comprobamos lo que hemos obtenido
			//alert(names.toString());
			//alert(values[2].length);
			
			//pintar(values, names);
			valores.push(values);
			nombres.push(names);
			
			
			//alert(values.length);
			pintar_splom(values,names)
			
				

		});
		
		
		
	}

	
	
	function pintar_splom(valores,nombres){
		var colors=[];

		for(i=0; i<valores[1].length; i++)
			colors.push(0.5);
		
		//alert(colors.length + ' ' + valores[0].length);

		var pl_colorscale=[
				   [0.0, '#19d3f3'],
				   [0.333, '#19d3f3'],
				   [0.333, '#e763fa'],
				   [0.666, '#e763fa'],
				   [0.666, '#636efa'],
				   [1, '#636efa']
		]

		var axis = () => ({
		  showline:false,
		  zeroline:false,
		  gridcolor:'#ffff',
		  ticklen:4
		})
		
		num_variables=$("#ejex option").length;
		var dimensiones=[];
		for(i=0;i<num_variables-1;i++)
			dimensiones.push({label:nombres[i], values: valores[i]})

		//alert("ok");

		var data = [{
		  type: 'splom',
		  dimensions: dimensiones,
		  text: nombres[0],
		  marker: {
			color: colors,
			colorscale:pl_colorscale,
			size: 4,
			line: {
			  color: colors,
			  colorscale:pl_colorscale,
			  width: 0.5
			}
		  }
		}]

		var layout = {
		  title:'Distribution of data',
		  height: 800,
		  width: 800,
		  autosize: false,
		  hovermode:'closest',
		  dragmode:'select',
		  plot_bgcolor:'rgba(240,240,240, 0.95)',
		  xaxis:axis(),
		  yaxis:axis(),
		  xaxis2:axis(),
		  xaxis3:axis(),
		  xaxis4:axis(),
		  yaxis2:axis(),
		  yaxis3:axis(),
		  yaxis4:axis()
		}

		Plotly.react('myDiv', data, layout)
	}
	
	function pearson(vector1, vector2){
		n=vector1.length;
		//Sumas simples
		sum1=0, sum2=0
		//Suma de cuadrados
		sum1_pow=0, sum2_pow=0
		//Suma de productos
		p_sum=0
		
		for(i=0;i<n;i++)
		{
			sum1=sum1 + vector1[i];
			sum2=sum2 + vector2[i];
			sum1_pow=sum1_pow + vector1[i]**2.0;
			sum2_pow=sum2_pow + vector2[i]**2.0;
			p_sum=p_sum +  vector1[i]*vector2[i];
		}
		
		numerador = p_sum - (sum1*sum2/n)
		denominador = Math.sqrt((sum1_pow - sum1**2.0 / n)*(sum2_pow - sum2**2.0 / n))
		if (denominador==0)
			return 0.0
		else
			return (numerador / denominador) ;
	}
	
	function spearman(vector1, vector2){
		N=vector1.length;
		order=[];
		sum=0;

		for(i=0;i<N;i++){
			order.push([vector1[i], vector2[i]]);
		}

		order.sort(function(a,b){
			return a[0]-b[0]
		});

		for(i=0;i<N;i++){
			order[i].push(i+1);
		}

		order.sort(function(a,b){
			return a[1]-b[1]
		});

		for(i=0;i<N;i++){
			order[i].push(i+1);
		}
		for(i=0;i<N;i++){
			sum+=Math.pow((order[i][2])-(order[i][3]), 2);

		}

		r=1-(6*sum/(N*(N*N-1)));

		return r;
	}

});