$(document).ready(function() {
	var valores=[];

	var nombres=[];
	var ensayos=[];
	
});

    //var id="628df05d497a8421874795fc";
	//splom(id);
	
	function splom(id){
		const names=[];//cada elemento será un string
		const values=[];//cada elemento será un array de valores
		//alert(id);
		
		myurl="http://localhost:3000/api/testings/" + id
		$.ajax({
			dataType: "json",
			url: myurl
		}).then(function(data) {
			//$('.myid').append(data._id);
			//$('.mycontent').append(data.testfile);
			//$('.mytype').append(data.type);
			var datos = data.data;
			
			var i=0;
			alert("cantidad de objetos encontrados:" + datos.length);
			$.each(datos, function(key,val){
				$.each(val, function(key2,val2){
					if (Array.isArray(val2)){
						//Guardamos el array de valores
						values[i]=val2;
						
					}
					else{
						//Guardamos el nombre
						names[i]=val2;
					}
				});
				i=i+1;//pasamos al siguiente objeto del array
			});
			//comprobamos lo que hemos obtenido
			//alert(names.toString());
			//alert(values[2].length);
			
			//pintar(values, names);
			valores.push(values);
			nombres.push(names);
			
			
			alert(values.length);
			pintar_splom(values,names)
			
				

		});
		
		
		
	}

	
	
function pintar_splom(valores,nombres){
		var colors=[];
		for(i=0; i<valores[0].length; i++)
			colors.push(0.5);
		
		
		
		alert(colors.length + ' ' + valores[0].length);

		var pl_colorscale=[
				   [0.0, '#19d3f3'],
				   [0.333, '#19d3f3'],
				   [0.333, '#e763fa'],
				   [0.666, '#e763fa'],
				   [0.666, '#636efa'],
				   [1, '#636efa']
		]

		var axis = () => ({
		  showline:false,
		  zeroline:false,
		  gridcolor:'#ffff',
		  ticklen:4
		})

		var data = [{
		  type: 'splom',
		  dimensions: [
			{label:nombres[0], values:valores[0]},
			{label:nombres[1], values:valores[1]},
			{label:nombres[2], values:valores[2]}
			
			//{label:'displacment', values:[9,8,7,6,5,4,3,2,1]},
			//{label:'aux1', values:[12,23,34,23,34,23,12,23,12]},
			//{label:'aux2', values:[12,23,23,34,23,12,23,34,12]}
		  ],
		  text: nombres[0],
		  marker: {
			color: colors,
			colorscale:pl_colorscale,
			size: 4,
			line: {
			  color: colors,
			  colorscale:pl_colorscale,
			  width: 0.5
			}
		  }
		}]

		var layout = {
		  title:'Distribution of data',
		  height: 800,
		  width: 800,
		  autosize: false,
		  hovermode:'closest',
		  dragmode:'select',
		  plot_bgcolor:'rgba(240,240,240, 0.95)',
		  xaxis:axis(),
		  yaxis:axis(),
		  xaxis2:axis(),
		  xaxis3:axis(),
		  xaxis4:axis(),
		  yaxis2:axis(),
		  yaxis3:axis(),
		  yaxis4:axis()
		}

		Plotly.react('myDiv', data, layout)
	}

	


