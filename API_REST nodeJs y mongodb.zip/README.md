# Puesta en Marcha del proyecto

## 1 Servicio de MongoDB

Verificar que el servicio MongoDB está en Ejecución

# 2 Arrancar el servdor API REST
Abrir consola de windows
Ir a la ruta:
C:\WINDOWS\System32>cd "C:\Users\ayuste\OneDrive - Batz S Coop\MASTERZONE\AÑO 2\2 CUATRIMESTRE\TFM\NODEJS.JS\32 API REST nodeJs y mongodb"
Ejecutar el comando: node server.js

Deberia salir el siguiente mensaje:
C:\Users\ayuste\OneDrive - Batz S Coop\MASTERZONE\AÑO 2\2 CUATRIMESTRE\TFM\NODEJS.JS\32 API REST nodeJs y mongodb>node server.js
Servidor web iniciado...
Conectado a la base de datos

# 3 Abrir URL de aplicacion web

http://ltayuste/qualitytestings/index.html