const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const Testings = require('./api/testings');

const app = express();

app.use(express.static('public'));
app.use('/static', express.static('public'));



app.use(bodyParser.urlencoded({ extended:false}));
app.use(bodyParser.json());

// Configurar cabeceras y cors
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Authorization, X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Allow-Request-Method');
    res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
    res.header('Allow', 'GET, POST, OPTIONS, PUT, DELETE');
    next();
});

app.use('/api/testings', Testings);


//le decimos que elservidor escuche en el puerto 3000
app.listen(3000, ()=>{
    console.log("Servidor web iniciado...");
});

//===============================================================================================================
//string de conexion 'mongodb://usuario:contraseña@servidor:puerto/database',{opciones}
//mongoose.connect('mongodb://dev:dev@localhost:27017/quality',{useNewUrlParser:true, useUnifiedTopology: true});
mongoose.connect('mongodb://localhost:30000,localhost:30001,localhost:30002/quality',{useNewUrlParser:true, useUnifiedTopology: true});
//cogemos la conexion
const connection=mongoose.connection;
//===============================================================================================================

//Añadimos eventos a la conexion 
//La primera vez 'once' que se ejecuta el evento 'open')
connection.once('open', () =>{
    console.log('Conectado a la base de datos');
});

//Evento de error. Cuando ocurra un error en la connection
connection.on('error', (err) =>{
    console.log('Error en la conexion: ' , err );
});


