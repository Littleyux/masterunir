const TestingController = require('../controllers/testings');
const express = require('express');

const router = express.Router();

router.get('/all', TestingController.findAllTestings);

router.get('/:id', TestingController.findById);

router.get('/tipo/:tipo', TestingController.findByType);

router.get('/getCompanies/:numero', TestingController.getCompanies);

router.get('/getTipos/:company', TestingController.getTipos);

router.get('/getAxis/:id', TestingController.getEjes);

router.get('/getTestings/:company/:type', TestingController.getTestingsByCompanyType);

router.get('/company/:id', TestingController.findByCompanyId);

router.get('/companyDate/:id/:anno/:mes/:dia', TestingController.findByCompanyDate);

router.post('/add',TestingController.addTesting);

module.exports = router;