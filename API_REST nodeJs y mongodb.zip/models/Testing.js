const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const testingSchema = new Schema({
    testfile:{type: String},
    company: {type: Number},
    type:{type: String},
    date:{type: Date},
    data:[{
        name:{type: String},
        values:[Number]
    }]
})

module.exports = Testing = mongoose.model('Testing',testingSchema);