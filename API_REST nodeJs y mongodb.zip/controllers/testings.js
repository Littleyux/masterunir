const mongoose = require('mongoose');
const Testing = require('../models/Testing');

//Controladores
const findAllTestings = (req, res) =>{
    Testing.find((err,testings)=>{
        err && res.status(500).send(err.message);

        res.status(200).json(testings);
    })
}

//Buscar por Id
const findById = (req, res) =>{
    Testing.findById(req.params.id, (err, testing)=>{
        err && res.status(500).send(err.message);

        res.status(200).json(testing);
    })
}

//Buscar por tipo de ensayo
const findByType = (req, res) =>{
    Testing.find({"type":req.params.tipo}, (err, testing)=>{
    
        //si ocurre algun error que devuelva error
        err && res.status(500).send(err.message);

        //si devuelve datos, devolver JSON
        res.status(200).json(testing);
    })
}

const getCompanies = (req, res) =>{
    Testing.distinct("company", (err, respuesta)=>{
        //si ocurre algun error que devuelva error
        err && res.status(500).send(err.message);
        //console.log(respuesta)
        //si devuelve datos, devolver JSON
        res.status(200).json({companies:respuesta});
    })
}

const getTipos = (req, res) =>{
    Testing.distinct("type",{"company":req.params.company}, (err, respuesta)=>{
        //si ocurre algun error que devuelva error
        err && res.status(500).send(err.message);
        //console.log(respuesta)
        //si devuelve datos, devolver JSON
        res.status(200).json({tipos:respuesta});
    })
}

//Obtener los ejes disponibles para graficar de un ensayo
const getEjes = (req, res) =>{
    Testing.distinct("data.name",{"_id": req.params.id }, (err, respuesta)=>{
        //si ocurre algun error que devuelva error
        err && res.status(500).send(err.message);
        //console.log(respuesta)
        //si devuelve datos, devolver JSON
        res.status(200).json({ejes:respuesta});
    })
}

//Buscar por Company y por tipo de
const getTestingsByCompanyType = (req, res) =>{
    Testing.find({
            "company":req.params.company,
            "type":req.params.type
        },
        '_id testfile company date type',
        (err, testing)=>{
        //si ocurre algun error que devuelva error
        err && res.status(500).send(err.message);

        //si devuelve datos, devolver JSON
        res.status(200).json(testing);
    })
}

//Buscar por company
const findByCompanyId = (req, res) =>{
    Testing.find({"company":req.params.id}, (err, testing)=>{
        //si ocurre algun error que devuelva error
        err && res.status(500).send(err.message);

        //si devuelve datos, devolver JSON
        res.status(200).json(testing);
    })
}

//Buscar por company y por fecha
const findByCompanyDate = (req, res) =>{
    var myDate = new Date(req.params.anno, req.params.mes-1, req.params.dia)
    var inputDate = new Date(myDate.toISOString()); 
    console.log(req.params.anno, req.params.mes, req.params.dia,inputDate);
    Testing.find({
            "company":req.params.id,
            "date":{$gte: inputDate}
        },
        'testfile company date type',
        (err, testing)=>{
        //si ocurre algun error que devuelva error
        err && res.status(500).send(err.message);

        //si devuelve datos, devolver JSON
        res.status(200).json(testing);
    })
}

//Añadir un nuevo test
const addTesting =(req,res)=>{
    let newtest = new Testing({
        testfile:req.body.testfile,
        company: req.body.company,
        type:req.body.type,
        date:new Date().toISOString(),
        data:req.body.data
    });

    newtest.save((err,tst) =>{
        err && res.status(500).send(err.message);
        res.status(200).json(tst);
    })
}

module.exports = {findAllTestings, findById, findByType,getCompanies, getTipos, getEjes, getTestingsByCompanyType, findByCompanyId, findByCompanyDate, addTesting};
