import os
import pymongo
import csv
import logging
import pandas as pd
import itertools
from threading import Timer, Thread, Event
import datetime

import sys  #system specific parameters and names
import gc   #garbage collector interface

#==============================================================
#RUTA DE LOS FICHEROS
path=".\in"
path_end=".\out"
#CARPETAS DE INSPECCION y CONFIGURACION
carpetas=[
  {"carpeta":"Moog","lineas":2,"delimitador":",","sepdecimal":'.'},
  {"carpeta":"Hoytom","lineas":0,"delimitador":'\t',"sepdecimal":','},
  {"carpeta":"Weiss","lineas":[0,1,2,3,4,6,7],"delimitador":";","sepdecimal":'.'}
]
#CONNECTION STRING A MONGODB
#connectionString = "mongodb://dev:dev@localhost:27017/quality"
connectionString = "mongodb://localhost:30000,localhost:30001,localhost:30002/?replicaSet=rs0"
databasename="quality"
collectionname="testings"
#==============================================================

#==============================================================
#FUNCION PARA CONVERTIR EL FICHERO PLANO EN JSON CON FORMATO DESEADO
#==============================================================
def procesar(df,filename,foldername):
  #print(df)
  number_of_rows = len(df.index) #numero de filas del dataframe
  print('Rows in dataframe : ', number_of_rows)
  #Creamos un documento JSON. En python tipo diccionario
  #Insertamos los datos basicos del documento JSON
  
  fecha = datetime.datetime.now()
  mydict= {
    "testfile": filename, 
    "company": 3, 
    "type": foldername,
    "date": fecha
    }
  #Los datos en nuestro documento son un array de N objetos
  #Tendremos tantos objetos como columnas contenga el fichero
  midata=[]
  minumpy = df.to_numpy() #convertimos el dataframe en una array de numpy
  numOfCols=minumpy.shape[1]
  if numOfCols == 1:
    raise Exception("Estructura de datos incorrecta")
  i=0
  #Iniciamos el recorrido de las columnas del fichero
  for col in df.columns:
    #Contar el numero de nulos de la columna df['column name'].isna().sum() 
    number_of_nan=df[col].isna().sum()
    number_of_zeros=(df[col] == 0.0).sum()
    print('Count of zeros in Column '+ col  +' : ', number_of_zeros)
    print('Count of NaN in Column '+ col  +' : ', number_of_nan)
    #solo insertamamos objetos que tengan algun valor distinto a nulo (nan)
    #si el numero de nan coincide con el numero de filas del dataframe, quiere decir que todos los valores son nulos
    #y por lo tanto no tiene sentido meterlo en la base de datos
    if number_of_rows > number_of_nan and number_of_rows > number_of_zeros:
      mivector=minumpy[:,i].tolist()
      miobjeto = {
        "name": col,      
        "values":mivector
      }
      #Añadimos el objeto al array de data
      midata.append(miobjeto)
      i=i+1
  #Fin del bucle
  #AÑADIMOS EL VECTOR DE OBJETOS AL DICCIONARIO
  mydict["data"]=midata
  return mydict

#==============================================================
#INSERTAR JSON GENERADO EN MONGODB
#==============================================================
def insertarDocumento(mydict):
  myclient = pymongo.MongoClient(connectionString)
  mydb = myclient[databasename]
  mycol = mydb[collectionname]
  #Lo insertamos en la coleccion
  x = mycol.insert_one(mydict)
  print(x.inserted_id)

#==============================================================
#FUNCIONES PARA VISUALIZAR CONSUMO DE MEMORIA
#==============================================================
def obj_size_fmt(num):
    if num<10**3:
        return "{:.2f}{}".format(num,"B")
    elif ((num>=10**3)&(num<10**6)):
        return "{:.2f}{}".format(num/(1.024*10**3),"KB")
    elif ((num>=10**6)&(num<10**9)):
        return "{:.2f}{}".format(num/(1.024*10**6),"MB")
    else:
        return "{:.2f}{}".format(num/(1.024*10**9),"GB")

def memory_usage():
    memory_usage_by_variable=pd.DataFrame({k:sys.getsizeof(v) for (k,v) in globals().items()},index=['Size'])
    memory_usage_by_variable=memory_usage_by_variable.T
    memory_usage_by_variable=memory_usage_by_variable.sort_values(by='Size',ascending=False).head(10)
    memory_usage_by_variable['Size']=memory_usage_by_variable['Size'].apply(lambda x: obj_size_fmt(x))
    print(memory_usage_by_variable)

#==============================================================
#Autodetectar el separador de un fichero de texto==============
#==============================================================
def find_delimiter(filename):
  head = ''.join(itertools.islice(open(filename), 100))
  print(head)
  #headers = csv.Sniffer().has_header(head)
  dialect = csv.Sniffer().sniff(head)
  print("sniffed CSV delimiter=%r" % (dialect.delimiter)) 
  sniffer = csv.Sniffer()
  with open(filename) as fp:
    #Establecemos un buffer de 5000 bytes. suficiente para determinr el separador
    delimiter = sniffer.sniff(fp.read(100000)).delimiter
  return delimiter

#================================================================
#Parametrizar el numero de lineas a saltar en el fichero de texto
#================================================================
def find_parameters(foldername):
  parameters=[]
  for carpeta in carpetas:
    print(foldername + " == " + carpeta["carpeta"])
    if foldername==carpeta["carpeta"]:
      parameters.append(carpeta["lineas"])
      parameters.append(carpeta["delimitador"])
      parameters.append(carpeta["sepdecimal"])
      break
    
  return parameters
 

#==============================================================
#Main Program. La ejecucion del programa comienza aquí
#==============================================================
def Importacion():
  logging.basicConfig(filename='Logs/app.log', filemode='a', format='%(asctime)s - %(message)s' , level=logging.DEBUG)
  for foldername in os.listdir(path):
    if os.path.isdir(foldername):
      try:
        for filename in os.listdir(path + "\\" + foldername):
          logging.info('procesando fichero:' + filename)
          parameters=find_parameters(foldername)
          #Creamos el dataframe de pandas
          df=pd.read_csv(path + "\\" + foldername + "\\" + filename,skiprows=parameters[0], sep=parameters[1],decimal=parameters[2], low_memory=False)

          mydict=procesar(df,filename, foldername)
          insertarDocumento(mydict)

          #borramos el dataframe de memoria
          del df

          #movemos el fichero a la zona de gestionados
          os.rename(path + "\\" + foldername + "\\" + filename,path_end + "\\" + foldername + "\\" + filename)
      except:
        logging.error('Error procesando el fichero:' + "\\" + foldername + "\\" + filename, exc_info=True)
        os.rename(path + "\\" + foldername + "\\" + filename,path_end + "\\Cuarentena\\" + filename)
        pass

    
class MyThread(Thread):
    def __init__(self, event):
        Thread.__init__(self)
        self.stopped = event

    def run(self):
        while not self.stopped.wait(10):
            Importacion()


stopFlag = Event()
thread = MyThread(stopFlag)
thread.start() 

